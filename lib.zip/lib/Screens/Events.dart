import 'package:nada_dco/Screens/EventSubCategory.dart';
import 'package:nada_dco/Screens/Success.dart';
import 'package:nada_dco/utilities/app_color.dart';
import 'package:nada_dco/utilities/app_font.dart';
import 'package:flutter/material.dart';
import '../utilities/app_constant.dart';
import '../utilities/app_image.dart';
import '../utilities/app_language.dart';
import 'package:http/http.dart' as http;
import 'package:table_calendar/table_calendar.dart';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';

class Events extends StatefulWidget {
  const Events({Key? key}) : super(key: key);

  @override
  _EventsState createState() => _EventsState();
}

class _EventsState extends State<Events> {
  List<dynamic> eventData = [];
  bool isLoading = true;
  String errorMessage = '';
  bool showCalendar = false;
  Map<int, List<DateTime>> _selectedDates = {}; // Changed to store multiple dates
  Map<int, DateTime> _focusedDays = {};
  bool _isLoading = false;
  String dateOfBirth = "MM/DD/YYYY";
  int? userId;

  void _onDaySelected(int eventId, DateTime selectedDay, DateTime focusedDay) {
    setState(() {
      _focusedDays[eventId] = focusedDay;

      // Initialize if not exists
      _selectedDates[eventId] ??= [];

      // Toggle date selection
      if (_selectedDates[eventId]!.any((date) => isSameDay(date, selectedDay))) {
        _selectedDates[eventId]!.removeWhere((date) => isSameDay(date, selectedDay));
      } else {
        _selectedDates[eventId]!.add(selectedDay);
      }
    });
  }

  bool _isSelected(int eventId, DateTime day) {
    return _selectedDates[eventId]?.any((date) => isSameDay(date, day)) ?? false;
  }

  @override
  void initState() {
    super.initState();
    fetchEventData();
    _getUserData();
  }

  Future<void> _getUserData() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        userId = prefs.getInt('user_id');
      });
      print('User ID: $userId');
    } catch (e) {
      print('Error accessing SharedPreferences: $e');
    }
  }

  Future<Map<String, dynamic>> markAvailability(int eventId, List<String> selectedDates) async {
    final body = {
      "event_id": eventId,
      "dco_user_id": userId,
      "marked_dates": selectedDates.map((date) => {"m_date": date}).toList(),
    };
    print("Request Body: ${jsonEncode(body)}");

    try {
      final response = await http.post(
        Uri.parse("https://nadaindia.in/api/web/index.php?r=event/mark-availability"),
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
        },
        body: jsonEncode(body),
      );

      final data = jsonDecode(response.body);
      bool status = data['status'] == true;
      String message = data['message'] ?? (status ? 'Marked successfully!' : 'Failed to mark availability.');

      return {"status": status, "message": message};
    } catch (e) {
      return {"status": false, "message": 'Error occurred: $e'};
    }
  }

  Future<void> fetchEventData() async {
    setState(() {
      isLoading = true;
      errorMessage = '';
    });

    try {
      final url = Uri.parse('https://nadaindia.in/api/web/index.php?r=base/active-event-list');
      final response = await http.get(url);

      if (response.statusCode == 200) {
        final Map<String, dynamic> jsonResponse = json.decode(response.body);

        if (jsonResponse['status'] == true) {
          setState(() {
            eventData = jsonResponse['data']['event_list'] ?? [];
            isLoading = false;
          });
        } else {
          setState(() {
            isLoading = false;
            errorMessage = jsonResponse['message'] ?? 'Failed to load events';
          });
        }
      } else {
        setState(() {
          isLoading = false;
          errorMessage = 'Failed to load events: ${response.statusCode}';
        });
      }
    } catch (e) {
      setState(() {
        isLoading = false;
        errorMessage = 'Error fetching events: $e';
      });
      print('Error fetching events: $e');
    }
  }

  String _formatDate(String dateString) {
    try {
      final date = DateTime.parse(dateString);
      return DateFormat('dd MMM yyyy').format(date);
    } catch (e) {
      return dateString;
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        centerTitle: true,
        elevation: 1,
        backgroundColor: Colors.white,
        systemOverlayStyle: Constant.systemUiOverlayStyle,
        leading: IconButton(
          icon: Image.asset(
            AppImage.backicon,
            height: 25,
            width: 25,
          ),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => EventSubCategory()),
            );
          },
        ),
        title: Text(
          AppLanguage.EventsText[language],
          style: Constant.appBarCenterTitleStyle,
        ),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Center(
            child: Container(
              width: MediaQuery.of(context).size.width,
              color: Colors.white,
              child: Column(
                children: [
                  SizedBox(height: MediaQuery.of(context).size.height * 0.02),

                  if (isLoading)
                    Padding(
                      padding: EdgeInsets.all(20),
                      child: Shimmer.fromColors(
                        baseColor: Colors.grey.shade200,
                        highlightColor: Colors.grey.shade50,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: List.generate(3, (index) {
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 12.0),
                              child: Container(
                                width: double.infinity,
                                height: 525,
                                color: Colors.white,
                              ),
                            );
                          }),
                        ),
                      ),
                    ),

                  if (errorMessage.isNotEmpty)
                    Padding(
                      padding: EdgeInsets.all(20),
                      child: Text(
                        errorMessage,
                        style: TextStyle(color: Colors.red),
                      ),
                    ),

                  if (!isLoading && errorMessage.isEmpty)
                    ...eventData.asMap().entries.map((entry) {
                      final index = entry.key;
                      final event = entry.value;
                      return Container(
                        width: MediaQuery.of(context).size.width,
                        margin: EdgeInsets.only(bottom: 16),
                        child: Column(
                          children: [
                            Container(
                              color: AppColor.greyBackgroundColor,
                              padding: EdgeInsets.symmetric(
                                horizontal: MediaQuery.of(context).size.width * 0.04,
                                vertical: 12,
                              ),
                              child: Column(
                                children: [
                                  SizedBox(
                                    width: MediaQuery.of(context).size.width * 0.92,
                                    child: Text(
                                      event['name'] ?? 'No event name',
                                      style: TextStyle(
                                        color: Colors.black,
                                        fontFamily: AppFont.fontFamily,
                                        fontSize: 15,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 12),
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                    children: [
                                      Row(
                                        children: [
                                          Image.asset(
                                            AppImage.locationIcon,
                                            width: 20,
                                            height: 20,
                                            color: Colors.black,
                                          ),
                                          SizedBox(width: 4),
                                          Text(
                                            event['location'] ?? 'No location found',
                                            style: TextStyle(
                                              color: Colors.black,
                                              fontSize: 11,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                      Row(
                                        children: [
                                          Image.asset(
                                            AppImage.calenderwhiteIcon,
                                            width: 20,
                                            height: 20,
                                            color: Colors.black,
                                          ),
                                          SizedBox(width: 4),
                                          Text(
                                            '${_formatDate(event['expected_start_datetime'])} - ${_formatDate(event['expected_end_datetime'])}',
                                            style: TextStyle(
                                              color: Colors.black,
                                              fontSize: 11,
                                              fontWeight: FontWeight.w500,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              color: Colors.white,
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  SizedBox(height: 8),
                                  // Show selected dates
                                  if (_selectedDates[index]?.isNotEmpty ?? false)
                                    Padding(
                                      padding: const EdgeInsets.symmetric(vertical: 4.0),
                                      child: Text(
                                        'Selected: ${_selectedDates[index]!.map((date) => DateFormat('MMM dd').format(date)).join(', ')}',
                                        style: TextStyle(fontSize: 15, fontWeight: FontWeight.w500),
                                      ),
                                    ),
                                  Container(
                                    height: MediaQuery.of(context).size.width * 0.85,
                                    width: MediaQuery.of(context).size.width * 0.98,
                                    child: ClipRRect(
                                      borderRadius: BorderRadius.circular(8),
                                      child: TableCalendar(
                                        firstDay: DateTime.now(),
                                        lastDay: DateTime.utc(2030, 12, 31),
                                        focusedDay: _focusedDays[index] ?? DateTime.now(),
                                        selectedDayPredicate: (day) => _isSelected(index, day),
                                        onDaySelected: (selectedDay, focusedDay) =>
                                            _onDaySelected(index, selectedDay, focusedDay),
                                        enabledDayPredicate: (day) {
                                          final today = DateTime.now();
                                          final todayDate = DateTime(today.year, today.month, today.day);
                                          final startDate = DateTime.parse(eventData[index]['expected_start_datetime']);
                                          final endDateRaw = DateTime.parse(eventData[index]['expected_end_datetime']);
                                          final endDatePlusOne = endDateRaw.add(Duration(days: 1));
                                          final effectiveStartDate = startDate.isAfter(todayDate) ? startDate : todayDate;
                                          return !day.isBefore(effectiveStartDate) && day.isBefore(endDatePlusOne);
                                        },
                                        calendarStyle: CalendarStyle(
                                          defaultTextStyle: TextStyle(color: Colors.black),
                                          weekendTextStyle: TextStyle(color: Colors.black),
                                          selectedTextStyle: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                          ),
                                          todayTextStyle: TextStyle(
                                            color: Colors.black,
                                            fontWeight: FontWeight.bold,
                                          ),
                                          todayDecoration: BoxDecoration(
                                            color: Colors.blueAccent,
                                            shape: BoxShape.circle,
                                          ),
                                          selectedDecoration: BoxDecoration(
                                            color: AppColor.themeColor.withOpacity(0.3),
                                            shape: BoxShape.circle,
                                            border: Border.all(
                                              color: AppColor.themeColor,
                                              width: 2,
                                            ),
                                          ),
                                          withinRangeTextStyle: TextStyle(color: Colors.black),
                                          disabledTextStyle: TextStyle(color: Colors.grey),
                                          defaultDecoration: BoxDecoration(
                                            color: Colors.green.withOpacity(0.1),
                                            shape: BoxShape.circle,
                                          ),
                                          outsideDecoration: BoxDecoration(
                                            shape: BoxShape.circle,
                                          ),
                                          weekendDecoration: BoxDecoration(
                                            color: Colors.green.withOpacity(0.1),
                                            shape: BoxShape.circle,
                                          ),
                                        ),
                                        headerStyle: HeaderStyle(
                                          formatButtonVisible: false,
                                          titleCentered: true,
                                          titleTextStyle: TextStyle(color: Colors.black),
                                        ),
                                        availableGestures: AvailableGestures.all,
                                        daysOfWeekStyle: DaysOfWeekStyle(
                                          weekdayStyle: TextStyle(color: Colors.black),
                                          weekendStyle: TextStyle(color: Colors.black),
                                        ),
                                        calendarBuilders: CalendarBuilders(
                                          selectedBuilder: (context, day, focusedDay) {
                                            return Stack(
                                              alignment: Alignment.center,
                                              children: [
                                                Center(
                                                  child: Container(
                                                    width: 36,
                                                    height: 36,
                                                    decoration: BoxDecoration(
                                                      color: AppColor.themeColor.withOpacity(0.3),
                                                      shape: BoxShape.circle,
                                                      border: Border.all(
                                                        color: AppColor.themeColor,
                                                        width: 2,
                                                      ),
                                                    ),
                                                    child: Center(
                                                      child: Text(
                                                        '${day.day}',
                                                        style: TextStyle(
                                                          color: Colors.black,
                                                          fontWeight: FontWeight.bold,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Positioned(
                                                  bottom: 0,
                                                  child: Text(
                                                    'Selected',
                                                    style: TextStyle(
                                                      color: AppColor.themeColor,
                                                      fontSize: 8,
                                                      fontWeight: FontWeight.bold,
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            );
                                          },
                                          defaultBuilder: (context, day, focusedDay) {
                                            final today = DateTime.now();
                                            final todayDate = DateTime(today.year, today.month, today.day);
                                            final startDate = DateTime.parse(eventData[index]['expected_start_datetime']);
                                            final endDateRaw = DateTime.parse(eventData[index]['expected_end_datetime']);
                                            final endDatePlusOne = endDateRaw.add(Duration(days: 1));

                                            // Check if date is in the future and enabled
                                            final isEnabled = !day.isBefore(todayDate) && day.isBefore(endDatePlusOne);

                                            // Check if date is in the past period (between start date and today)
                                            final isExpiredPeriod = !day.isBefore(startDate) && day.isBefore(todayDate);

                                            if (isEnabled) {
                                              return Stack(
                                                alignment: Alignment.center,
                                                children: [
                                                  Center(
                                                    child: Container(
                                                      width: 32,
                                                      height: 32,
                                                      decoration: BoxDecoration(
                                                        color: Colors.green.withOpacity(0.18),
                                                        shape: BoxShape.circle,
                                                      ),
                                                      child: Center(
                                                        child: Text(
                                                          '${day.day}',
                                                          style: TextStyle(color: Colors.black),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    bottom: 1,
                                                    child: Text(
                                                      'Available',
                                                      style: TextStyle(
                                                        color: Colors.green[800],
                                                        fontSize: 8,
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              );
                                            } else if (isExpiredPeriod) {
                                              return Stack(
                                                alignment: Alignment.center,
                                                children: [
                                                  Center(
                                                    child: Container(
                                                      width: 32,
                                                      height: 32,
                                                      decoration: BoxDecoration(
                                                        color: Colors.red.withOpacity(0.18),
                                                        shape: BoxShape.circle,
                                                      ),
                                                      child: Center(
                                                        child: Text(
                                                          '${day.day}',
                                                          style: TextStyle(color: Colors.black),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    bottom: 0,
                                                    child: Text(
                                                      'Expired',
                                                      style: TextStyle(
                                                        color: Colors.red[800],
                                                        fontSize: 8,
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              );
                                            }
                                            return Center(
                                              child: Text(
                                                '${day.day}',
                                                style: TextStyle(color: Colors.grey),
                                              ),
                                            );
                                          },
                                          disabledBuilder: (context, day, focusedDay) {
                                            final startDate = DateTime.parse(eventData[index]['expected_start_datetime']);
                                            final today = DateTime.now();
                                            final todayDate = DateTime(today.year, today.month, today.day);

                                            // Check if date is in the past period (between start date and today)
                                            final isExpiredPeriod = !day.isBefore(startDate) && day.isBefore(todayDate);

                                            if (isExpiredPeriod) {
                                              return Stack(
                                                alignment: Alignment.center,
                                                children: [
                                                  Center(
                                                    child: Container(
                                                      width: 32,
                                                      height: 32,
                                                      decoration: BoxDecoration(
                                                        color: Colors.red.withOpacity(0.18),
                                                        shape: BoxShape.circle,
                                                      ),
                                                      child: Center(
                                                        child: Text(
                                                          '${day.day}',
                                                          style: TextStyle(color: Colors.black),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  Positioned(
                                                    bottom: 4,
                                                    child: Text(
                                                      'Expired',
                                                      style: TextStyle(
                                                        color: Colors.red[800],
                                                        fontSize: 8,
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              );
                                            }
                                            return Center(
                                              child: Text(
                                                '${day.day}',
                                                style: TextStyle(color: Colors.grey),
                                              ),
                                            );
                                          },
                                        ),
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: MediaQuery.of(context).size.height * 0.04),
                                  Container(
                                    width: MediaQuery.of(context).size.width * 0.9,
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      children: [
                                        GestureDetector(
                                          onTap: () async {
                                            if (_selectedDates[index]?.isNotEmpty ?? false) {
                                              List<String> selectedDates = _selectedDates[index]!
                                                  .map((date) => DateFormat('yyyy-MM-dd').format(date))
                                                  .toList();
                                              int eventId = eventData[index]['id'];

                                              setState(() {
                                                _isLoading = true;
                                              });

                                              final result = await markAvailability(eventId, selectedDates);

                                              setState(() {
                                                _isLoading = false;
                                              });

                                              ScaffoldMessenger.of(context).showSnackBar(
                                                SnackBar(
                                                  content: Text(result['message']),
                                                  backgroundColor: result['status'] ? Colors.green : Colors.red,
                                                ),
                                              );
                                            } else {
                                              ScaffoldMessenger.of(context).showSnackBar(
                                                SnackBar(
                                                  content: Text('Please select at least one date.'),
                                                  backgroundColor: Colors.red,
                                                ),
                                              );
                                            }
                                          },
                                          child: Container(
                                            height: MediaQuery.of(context).size.height * 0.045,
                                            width: MediaQuery.of(context).size.width * 0.48,
                                            alignment: Alignment.center,
                                            decoration: BoxDecoration(
                                              color: AppColor.themeColor,
                                              borderRadius: BorderRadius.circular(6),
                                            ),
                                            child: _isLoading
                                                ? SizedBox(
                                              height: 20,
                                              width: 20,
                                              child: CircularProgressIndicator(
                                                strokeWidth: 2,
                                                color: Colors.white,
                                              ),
                                            )
                                                : Text(
                                              AppLanguage.MarkAvilaibilityText[language],
                                              style: TextStyle(
                                                color: Colors.black,
                                                fontSize: 15,
                                                fontWeight: FontWeight.w600,
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            )
                          ],
                        ),
                      );
                    }).toList(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}