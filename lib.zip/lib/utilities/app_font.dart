class AppFont {
  static const fontFamily = 'GoogleSans';
}
